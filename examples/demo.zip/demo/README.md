# 无人机视频投放、无人机视频叠加矢量、无人机视频标绘示例

本目录为「无人机视频叠加矢量」相关示例，演示 SuperMap iClient for MapboxGL 的视频地图能力：
无人机视频投放、无人机视频叠加矢量、以及无人机视频标绘。


- 页面为**自包含静态页面**，只引用本目录内 `css/`、`js/` 下的资源，
- 只要把本目录连同 `css/`、`js/` 一起拷贝出去，用任意静态服务器打开即可运行。

## 一、如何打开示例

> ⚠️ 必须通过 **HTTP 方式** 打开，不能直接双击用 `file://` 打开。
> 示例需要跨域请求 iServer 的视频/数据服务，`file://` 协议会被浏览器拦截（CORS）。

### 方式一：VS Code Live Server 插件（推荐，最省事）

1. 用 VS Code 打开本 `demo` 目录（或把它直接拖进 VS Code）。
2. 在扩展市场搜索并安装 **Live Server**。
3. 在任意示例 HTML 上右键，选择 **Open with Live Server**。
4. 浏览器会自动打开，地址形如：

   ```
   http://127.0.0.1:5500/videoMapWithTime.html
   ```

> 其他同类插件亦可，如 **Preview on Web Server**、**Five Server** 等，用法基本一致。


### 方式二：已有 Web 服务器（IIS / Nginx / Tomcat 等）

把整个 `demo` 目录拷贝到服务器的静态资源目录下，
通过 `http://<服务器地址>/<部署路径>/videoMapWithTime.html` 访问即可。

### 前置条件

| 项 | 说明 |
| --- | --- |
| 浏览器 | 建议使用 Chrome / Edge 等现代浏览器 |
| 目录完整性 | `demo` 目录需连同 `css/`、`js/` 一并拷贝，缺失会导致页面样式或脚本加载失败 |
| 数据服务 | 需可访问示例中配置的 iServer 数据服务地址（见各页面的 `host` 变量） |
| 天地图密钥 | 部分示例使用天地图影像底图，需有效的 `tk`（天地图 Token） |
| iClient 资源和相关三方库 | `css/`、`js/` 下已放好所需文件，无需另行构建 |

## 二、文件说明

### 2.1 目录结构

```
demo/                       ← 独立打包交付的根目录
├── README.md               ← 本文档
├── videoLayerWithTime.html            无人机视频投放
├── videoMapWithTime.html              无人机视频叠加矢量
├── videoMapWithTimeDraw.html          无人机视频标绘
├── videoMapWithTime_huainan.html      无人机视频叠加矢量 - 淮南
├── videoMapWithTime_huainanDraw.html  无人机视频标绘 - 淮南
├── css/                    ← 页面样式（5 个文件）
│   ├── iclient-mapboxgl.min.css / iclient-mapboxgl.css
│   ├── mapbox-gl-enhance.css
│   ├── mapbox-gl-draw.min.css
│   └── video-js.min.css
└── js/                     ← 页面脚本（10 个文件）
    ├── iclient-mapboxgl.min.js / iclient-mapboxgl.js
    ├── iclient-mapboxgl-es6.min.js / iclient-mapboxgl-es6.js
    ├── mapbox-gl-enhance.js
    ├── mapbox-gl-draw.min.js
    ├── proj4.min.js
    ├── turf.min.js
    ├── video.min.js
    └── opencv.js
```

所有页面均以 `css/xxx.css`、`js/xxx.js` 的**相对路径**引用同级目录资源，
因此**整目录拷贝到任何位置都能直接运行**。

### 2.2 页面文件

| 文件 | 标题 | 说明 | 依赖服务 |
| --- | --- | --- | --- |
| `videoLayerWithTime.html` | 无人机视频投放 | 使用带时间参数的视频图层，按时间插值更新视频画面在地图上的成像范围 | `https://iserver.supermap.io`（data-video） |
| `videoMapWithTime.html` | 无人机视频叠加矢量 | 基于视频参数（内外方位元素）创建视频地图，按 `interval` 自动播放并随时间更新成像范围 | `https://iserver.supermap.io`（data-video） |
| `videoMapWithTimeDraw.html` | 无人机视频标绘 | 左侧视频地图 + 右侧天地图影像，支持在天地图影像上标绘点/线/面并同步到视频地图；标绘后点击“保存”上传，支持删除已保存要素 | `https://iserver.supermap.io`（data-video、data-edit） |
| `videoMapWithTime_huainan.html` | 无人机视频叠加矢量 - 淮南 | 淮南项目数据的视频地图示例 | `http://172.16.14.44:8090`（data-huainan） |
| `videoMapWithTime_huainanDraw.html` | 无人机视频标绘 - 淮南 | 淮南项目的视频地图与天地图影像标绘对比，含长度/面积量算；标绘后点击“保存”上传，支持删除已保存要素 | `http://172.16.14.44:8090`（data-huainan、数据编辑服务） |

> 两个「淮南」示例指向内网服务地址 `http://172.16.14.44:8090`，
> 在非该网络环境下无法加载数据，如需使用请把页面中的 `host` 改为自己的 iServer 地址。

标绘示例的保存和删除规则：视频地图、天地图两侧新绘制的要素都会先保留在本地，点击页面左下角的“保存”后才上传到数据服务；删除未保存要素只影响当前页面。

### 2.3 样式文件 `css/`

| 文件 | 说明 |
| --- | --- |
| `iclient-mapboxgl.min.css` | SuperMap iClient for MapboxGL 样式（含控件、Popup 等，页面实际引用） |
| `iclient-mapboxgl.css` | 同上，未压缩版 |
| `mapbox-gl-enhance.css` | mapbox-gl-enhance 增强版地图引擎样式 |
| `mapbox-gl-draw.min.css` | MapboxGL Draw 标绘工具样式（仅标绘示例使用） |
| `video-js.min.css` | video.js 播放器样式（各视频示例均使用） |

### 2.4 脚本文件 `js/`

**iClient 及地图引擎**

| 文件 | 说明 |
| --- | --- |
| `iclient-mapboxgl.min.js` | SuperMap iClient for MapboxGL（ES5 构建，示例实际引用） |
| `iclient-mapboxgl.js` | 同上，未压缩版 |
| `iclient-mapboxgl-es6.min.js` | ES6 构建，支持 ES6 模块语法的浏览器可改用此文件 |
| `iclient-mapboxgl-es6.js` | 同上，未压缩版 |
| `mapbox-gl-enhance.js` | mapbox-gl-enhance 增强版地图引擎（提供 4326/3857 投影切换、VideoMap 等能力） |

**第三方库**

| 文件 | 说明 | 用于 |
| --- | --- | --- |
| `turf.min.js` | Turf.js 空间分析库 | 计算成像范围、中心点、长度/面积 |
| `proj4.min.js` | proj4js 坐标系转换库 | 3857 ↔ 4326 坐标互转 |
| `video.min.js` | video.js 视频播放器 | 播放无人机视频 |
| `opencv.js` | OpenCV.js | 视频帧图像处理 |
| `mapbox-gl-draw.min.js` | MapboxGL Draw 标绘工具 | 标绘示例中的点/线/面绘制 |

### 2.5 引用顺序

页面按以下顺序**手动引入**同目录资源，顺序不可调换：

```html
<!-- 1. 第三方基础库 -->
<script src="js/mapbox-gl-enhance.js"></script>
<script src="js/turf.min.js"></script>
<script src="js/mapbox-gl-draw.min.js"></script> <!-- 仅标绘示例 -->
<script src="js/proj4.min.js"></script>
<script src="js/video.min.js"></script>
<script src="js/opencv.js"></script>
<!-- 2. iClient 必须最后引入 -->
<script src="js/iclient-mapboxgl.min.js"></script>
```

对应样式在 `<head>` 中引入：

```html
<link rel="stylesheet" href="css/mapbox-gl-enhance.css" />
<link rel="stylesheet" href="css/video-js.min.css" />        <!-- 按需 -->
<link rel="stylesheet" href="css/mapbox-gl-draw.min.css" />  <!-- 按需 -->
<link rel="stylesheet" href="css/iclient-mapboxgl.min.css" />
```

## 三、常见配置项

页面顶部通常有以下变量，按需修改：

| 变量 | 说明 |
| --- | --- |
| `host` | iServer 服务根地址，如 `https://iserver.supermap.io` |
| `dataUrl` | 数据服务地址，一般为 `host + '/iserver/services/xxx/rest/data'` |
| `dataSourceName` / `datasourceName` | 数据源名称 |
| `datasetName` | 数据集名称（如视频参数数据集 `DJI_09304`） |
| `tk` | 天地图 Token，用于加载天地图影像底图 |

## 四、常见问题

| 现象 | 原因与处理 |
| --- | --- |
| 页面空白、控制台报跨域错误 | 用了 `file://` 打开，请改用 Live Server 或 HTTP 静态服务器访问 |
| 页面无样式、控制台报 404 | 只拷贝了 html，漏拷 `css/`、`js/` 目录，需整目录一起打包 |
| 视频不播放 / 无成像范围 | 无法访问 `host` 指向的 iServer 服务，检查地址与网络 |
| 底图不显示 | 天地图 `tk` 失效或超额度，需更换有效 Token |
| 淮南示例无数据 | 该示例指向内网 `172.16.14.44`，需在对应网络环境或改为自有服务地址 |
| 标绘示例右侧地图无标绘工具 | 未引入 `js/mapbox-gl-draw.min.js` 或 `css/mapbox-gl-draw.min.css` |